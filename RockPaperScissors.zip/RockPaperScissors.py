import tkinter as tk

def play_game():
    global PlayerOneScore, PlayerTwoScore
    PlayerOnePrompt = player_one_input.get()
    PlayerTwoPrompt = player_two_input.get()

    outcomes = {
        ("R", "R"): "Draw",
        ("R", "P"): "Point for Player Two",
        ("R", "S"): "Point for Player One",
        ("P", "R"): "Point for Player One",
        ("P", "P"): "Draw",
        ("P", "S"): "Point for Player Two",
        ("S", "R"): "Point for Player Two",
        ("S", "P"): "Point for Player One",
        ("S", "S"): "Draw",
    }

    result = outcomes.get((PlayerOnePrompt, PlayerTwoPrompt), "Invalid input")
    result_label.config(text=result, fg="blue" if "Player One" in result else "red")

    if "Player One" in result:
        PlayerOneScore += 1
    elif "Player Two" in result:
        PlayerTwoScore += 1

    score_label.config(text=f"Player One: {PlayerOneScore}   Player Two: {PlayerTwoScore}")

    if PlayerOneScore == 3 or PlayerTwoScore == 3:
        game_over_label.config(text="Game Over", fg="purple")
        play_button.config(state=tk.DISABLED)

# Create the GUI window
window = tk.Tk()
window.title("Rock Paper Scissors Game")

# Game variables
PlayerOneScore = 0
PlayerTwoScore = 0

# Create and arrange GUI elements
player_one_label = tk.Label(window, text="Player One: ")
player_one_label.pack()

player_one_input = tk.Entry(window)
player_one_input.pack()

player_two_label = tk.Label(window, text="Player Two: ")
player_two_label.pack()

player_two_input = tk.Entry(window)
player_two_input.pack()

play_button = tk.Button(window, text="Play", command=play_game)
play_button.pack()

result_label = tk.Label(window, text="")
result_label.pack()

score_label = tk.Label(window, text="Player One: 0   Player Two: 0")
score_label.pack()

game_over_label = tk.Label(window, text="")
game_over_label.pack()

# Start the GUI event loop
window.mainloop()
