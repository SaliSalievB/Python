import random
import time

# words that will be used in text as game commentary

NUMBER_WORDS = 'zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty twenty-one twenty-two twenty-three twenty-four twenty-five'.split()
NUMBER_PLURALS = 'q ones twos threes fours fives sixes'.split()
# different names for the opponents

names = 'Niki, F1z, Anelia, Garet, Jack, TheBlade, Kenaki, BladeX, Okumura, Veni, Denice, Gorge, Anastasia, '.split()


def pause():
    time.sleep(1)


# Start of the game,defines number of players

def start_game():
    bad = True
    while bad:
        print("\nHow many players?")
        p = input()
        if p.isdigit():
            p = int(p)
            if p < 2:
                print("You can't play this alone duh")
            elif p > 5:
                print("Please choose a number of players from 2 to 5.")
            else:
                bad = False
    return p


# initializes the computer as the opponent and gives it a random name

def init_npc(num_cpu):
    cpu_p = []
    for x in range(num_cpu):
        n = names[random.randint(0, len(names) - 1)]
        names.remove(n)
        cpu_p.append([[0, 0, 0, 0, 0], 5, n, False])
    return cpu_p


# rolls the dice

def roll_dice(player_info):
    # uses an array of 4 slots for each player, each slot for each dice

    player_info[0] = [0, 0, 0, 0, 0]
    # uses random module for the random outcome of the dice rolling

    for x in range(player_info[1]):
        player_info[0][x] = random.randint(1, 6)
    # uses a sorting method for a more clear display of the dices

    player_info[0].sort()
    return player_info


def valid_bet(old_bet, new_bet):
    if old_bet[0] > new_bet[0] or (old_bet[0] == new_bet[0] and old_bet[1] >= new_bet[1]) or new_bet[0] > 24 or new_bet[1] > 6:

        return False
    else:
        return True


def bet(who, p, old_bet):
    new_bet = [0, 0]
    if p[who][3]:
        wrong = True
        while wrong:
            print('What you like to bet? [Number of dice] [Value of dice]')
            new_bet = input()

            # print(new_bet)

            new_bet = new_bet.split()
            if len(new_bet) > 1 and new_bet[0].isdigit() and new_bet[1].isdigit():
                new_bet = [int(new_bet[0]), int(new_bet[1])]
                if valid_bet(old_bet, new_bet):
                    wrong = False

    else:
        best_value = old_bet[1]
        best_odds = 0
        for x in range(1, 7):
            odds = calc_odds(who, p, x)
            if x <= old_bet[1]:
                odds -= 1
            if odds > best_odds:
                best_value = x
                best_odds = odds
        if best_value <= old_bet[1]:
            new_bet[0] = old_bet[0] + 1
        else:
            new_bet[0] = old_bet[0]
        new_bet[1] = best_value

    print(p[who][2] + ' bets that there are ' + NUMBER_WORDS[new_bet[0]] + ' ' + NUMBER_PLURALS[
        new_bet[1]] + ' on the table.\n')
    pause()
    pause()
    return new_bet


def calc_odds(who, p, value):
    num_of_dice = 0
    for x in range(maxPlayers):
        num_of_dice += p[x][1]
    num_of_dice -= p[who][1]
    return round(num_of_dice / 6) + p[who][0].count(value)


def human_choice(prev_player):
    print('Would you like to [b]et or call ' + prev_player + ' a [l]iar')
    fake = True
    while fake:
        d = input()
        if d == 'b':
            return 0
        if d == 'l':
            return 1
        if d == 's':
            return 2
        print('Invalid input. Please enter the letter b or l')


def cpu_choice(who, p, old_bet):
    odds = calc_odds(who, p, old_bet[1])
    if old_bet[0] == odds:
        if random.randint(0, 1) == 0:
            return 2
        else:
            return 0
    if old_bet[0] > odds:
        return 1
    else:
        return 0


def count_dice(p, value):
    total = 0
    for x in range(maxPlayers):
        d = p[x][0].count(value)
        total = d + total
        print(p[x][2] + ' has ' + NUMBER_WORDS[d] + ' ' + NUMBER_PLURALS[value] + '.', end=' ')
        for y in range(5):
            if p[x][0][y] != 0:
                print('[' + str(p[x][0][y]) + ']', end=' ')
        print()
        pause()
    pause()
    print('There are a total of ' + NUMBER_WORDS[total] + ' ' + NUMBER_PLURALS[value] + ' on the table.\n')
    pause()
    return total


def bluff(who, p, old_bet):
    print(p[who][2] + ' thinks ' + p[(who - 1) % maxPlayers][2] + ' is full of it.\n')
    if count_dice(p, old_bet[1]) >= old_bet[0]:
        p[who][1] -= 1
        print('Bad call. ' + p[who][2] + ' loses a die, they now have ' + NUMBER_WORDS[p[who][1]] + ' dice.')
    else:
        p[(who - 1) % maxPlayers][1] -= 1
        print('Great call, ' + p[who][2] + '! ' + p[(who - 1) % maxPlayers][2] + ' loses a die. They now have only ' +
              NUMBER_WORDS[p[(who - 1) % maxPlayers][1]] + ' dice.\n')
    return p





def remove_players(p):
    m_p = maxPlayers
    dead = []
    for x in range(maxPlayers):
        if p[x][1] == 0:
            m_p -= 1
            print(p[x][2] + ' is out of the game.\n')
            pause()
            dead.append(x)

    for x in range(len(dead)):
        p.pop(dead[x])
    pause()
    return [p, m_p]


print('What is your name?')
temp = input()
maxPlayers = start_game()
players = init_npc(maxPlayers - 1)
players.append([[0, 0, 0, 0, 0], 5, temp, True])

gameContinues = True
goesNext = random.randint(0, maxPlayers - 1)

while gameContinues:
    for x in range(maxPlayers):
        players[x] = roll_dice(players[x])

    roundContinues = True
    currentBet = [0, 6]
    if players[goesNext][3]:
        print('\nYour hand: ')
        t = 0
        for y in range(5):
            if players[goesNext][0][y] != 0:
                print('[' + str(players[goesNext][0][y]) + ']', end=' ')
            if y < maxPlayers:
                t += players[y][1]
        print('\nThere are ' + str(t - players[goesNext][1]) + ' other dice on the table.\n')
    print(players[goesNext][2] + ' starts. Please place the first bet.\n')
    currentBet = bet(goesNext, players, currentBet)
    while roundContinues:
        goesNext = (goesNext + 1) % (maxPlayers)
        if players[goesNext][3]:
            print("It's your turn. Your hand: ", end="")
            t = 0
            for y in range(5):
                if players[goesNext][0][y] != 0:
                    print('[' + str(players[goesNext][0][y]) + ']', end=' ')
                if y < maxPlayers:
                    t += players[y][1]
            print('\nThere are ' + str(t - players[goesNext][1]) + ' other dice on the table.')
            choice = human_choice(players[(goesNext - 1) % (maxPlayers)][2])
        else:
            choice = cpu_choice(goesNext, players, currentBet)
        if choice == 0:
            currentBet = bet(goesNext, players, currentBet)
        elif choice == 1:
            players = bluff(goesNext, players, currentBet)
            roundContinues = False

    temp = remove_players(players)
    players = temp[0]
    if maxPlayers != temp[1]:
        maxPlayers = temp[1]
        goesNext = (goesNext - 1) % maxPlayers
    temp = []

    if maxPlayers == 1:
        gameContinues = False
        print('\nCongratulations! ' + players[goesNext][2] + ' is the winner.')